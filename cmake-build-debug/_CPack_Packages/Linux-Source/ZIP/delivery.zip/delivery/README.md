
# Trabalho de programação

## Grupo

Diogo Filipe Faia Nunes - 202007895

## Tarefas realizadas

Indique aqui as tarefas que conseguiu realizar e quais não. 

Classe color implementada e passou em todos os testes.

Classe image implementada e passou em todos os testes.

Estao implementados e testados os seguintes metodos na classe Script:

Fill \
Grayscale \
Invert \
Replace \
Crop(poderia ser simplificado?) \
Rotate(poderia ser simplificado, muito codigo repetido) \
Mix \
Add 

Falta terminar:
Doxygen

 
